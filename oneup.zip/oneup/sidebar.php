<?php
/**
 * The sidebar containing the widget area
 *
 * @package WordPress
 * @subpackage Theme
 * @since 1.0
 */
?>
<div class="span4 sidebar">
	 <div class="inner-spacer-left-lrg">
		 <?php peTheme()->sidebar->show("default"); ?>
	 </div>
</div>